{{-- Accreditations marquee — auto-detects logo images in public/images/accreditations/ --}}
@php
    // Resolve public path (works in Laravel and in the static preview renderer)
    $accBase = function_exists('public_path')
        ? public_path('images/accreditations')
        : (is_dir(getcwd() . '/kvs/public/images/accreditations')
            ? getcwd() . '/kvs/public/images/accreditations'
            : getcwd() . '/public/images/accreditations');

    $accLogos = [];
    if (is_dir($accBase)) {
        foreach (scandir($accBase) as $f) {
            if (preg_match('/\.(png|jpe?g|svg|webp)$/i', $f)) {
                $accLogos[] = 'images/accreditations/' . $f;
            }
        }
        sort($accLogos);
    }

    $accNames = ['University of Cambridge', 'Pearson Edexcel', 'Oxford International AQA', 'British Council', 'Goethe-Institut', 'Institut Français'];
@endphp

<div class="relative border-t border-gold-700/25 bg-black/25">
    <div class="container-site py-6">
        <p class="text-center text-[11px] tracking-[0.3em] uppercase text-ivory/50 mb-4">Accredited by &amp; partnered with</p>

        @if (count($accLogos))
        {{-- Animated logo marquee --}}
        <div class="marquee" aria-label="Our accreditations and partners">
            <div class="marquee-track">
                @foreach ([0, 1] as $half)
                <div class="marquee-half flex items-center" @if ($half === 1) aria-hidden="true" @endif>
                    @foreach ($accLogos as $logo)
                    <div class="mx-8 sm:mx-10 flex items-center justify-center h-14 sm:h-16 w-28 sm:w-36 shrink-0">
                        <img src="/{{ $logo }}" alt="{{ $half === 0 ? pathinfo($logo, PATHINFO_FILENAME) : '' }}"
                             class="max-h-full max-w-full object-contain brightness-0 invert opacity-80 hover:opacity-100 transition-opacity"
                             loading="lazy" height="64">
                    </div>
                    @endforeach
                </div>
                @endforeach
            </div>
        </div>
        @else
        {{-- Fallback: text marquee until logo images are added --}}
        <div class="marquee" aria-label="Our accreditations and partners">
            <div class="marquee-track">
                @foreach ([0, 1] as $half)
                <div class="marquee-half flex items-center" @if ($half === 1) aria-hidden="true" @endif>
                    @foreach ($accNames as $name)
                    <span class="mx-8 sm:mx-10 whitespace-nowrap font-display font-semibold text-lg text-gold-300/90 flex items-center gap-8 sm:gap-10">
                        {{ $name }}
                        <span class="text-gold-700 text-sm" aria-hidden="true">✦</span>
                    </span>
                    @endforeach
                </div>
                @endforeach
            </div>
        </div>
        @endif
    </div>
</div>
